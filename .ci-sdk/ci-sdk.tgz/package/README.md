# ci-sdk

Insanely fast CI. No migration. By [Diffling](https://diffling.com).

ci-sdk makes the CI you already have skip work your change can't affect: packages whose inputs didn't change, tests your change can't reach, and jobs that already passed on the same code. No pipeline to rewrite, no config, any runner.

On [React Router](https://github.com/remix-run/react-router) (10 packages), whole CI jobs (setup, install, build, typecheck, lint, unit tests) ran **40% faster on pushes and 27% faster on pull requests**, with the same results, replaying real commits on GitHub's standard runners. Gains are largest in monorepos with many packages and commits that touch a few of them; repos whose jobs take only seconds gain little.

Needs Node 22.18 or newer. Works with pnpm and npm workspaces (yarn and bun run through their own `run`).

## run

Run a package script in every workspace package, skipping packages whose inputs haven't changed since they last passed:

```bash
npx ci-sdk run build
npx ci-sdk run typecheck
```

- A package reruns when its own files, a workspace package it depends on, or its dependencies in `pnpm-lock.yaml` change. Docs, changelogs, licenses and CI config don't count.
- Outputs are whatever the script creates outside git. On a cache hit they are restored and the script's log is replayed. No config.
- Packages run dependencies first, up to 4 at a time. Failures are never cached, and packages that depend on a failure don't run.
- Ends with how long the run took and how much time cache hits saved, so you can compare it with a plain `npm run build`.
- The cache lives in `node_modules/.cache/ci-sdk`. In CI, entries the run didn't use are pruned, so a saved cache stays small.
- `--filter './packages/*'` limits it to some folders. `--no-cache` runs everything and refreshes the cache.
- Environment variables are not part of a package's inputs. If a script's output depends on one, run it with `--no-cache`.

## test

Run only the tests your changes can reach:

```bash
npx ci-sdk test                      # uncommitted and untracked changes
npx ci-sdk test --since origin/main  # plus commits on your branch
npx ci-sdk test --since HEAD~1       # in CI: the commit being tested
```

- Follows imports through barrel files, so a change in a shared package only runs the tests that use it.
- Runs each package's own test script with the affected files. Packages without one run through the root's script, such as `jest` or `vitest run`. `--script test-unit` picks a different script.
- If a change can affect everything, such as a root config, it runs the full suite.
- It never reports success for tests it couldn't run: if no script can take the affected files, it fails and names them.
- `--list` prints the affected test files instead of running them.

## GitHub Action

Restores tool caches (Turborepo, Next.js, ESLint, `node_modules/.cache`, which includes ci-sdk's own) and tells you when this exact code already passed this job:

```yaml
steps:
  - uses: actions/checkout@v6
    with:
      fetch-depth: 2 # lets `ci-sdk test --since HEAD~1` see the commit's changes
  - uses: pnpm/action-setup@v6
  - uses: actions/setup-node@v7
    with:
      node-version: 24
  - id: ci-sdk
    uses: jaymalve/ci-sdk@v0.0.6
  - if: steps.ci-sdk.outputs.already-passed != 'true'
    run: |
      pnpm install --frozen-lockfile
      npx ci-sdk run build
      npx ci-sdk run typecheck
      npx ci-sdk test --since HEAD~1
```

- Add `ci-sdk` to your devDependencies to pin its version; `npx` then uses the installed copy instead of downloading it.
- `already-passed` is `true` when this job already passed on the same code (same git tree, job and matrix). Skip the rest of the job when it is.
- Each run saves a fresh cache entry and restores the latest one. On pull requests, that includes the base branch's.
- Sets each tracked file's modification time from its content, so caches that compare times, such as ESLint's `--cache`, hit across fresh checkouts. On React Router this cut lint from 170s to 43s over 10 pushes. Turn it off with `pin-file-times: false`.
- For a check-only `tsc` run on the whole repo, add `--incremental --tsBuildInfoFile node_modules/.cache/tsc/check.tsbuildinfo` to your typecheck script; the Action carries that file between runs, so `tsc` re-checks only what changed.
- On runners that serve the GitHub Actions cache API from their own storage, such as Blacksmith and Depot, the Action uses that automatically.

## scan

See where your GitHub Actions minutes and dollars go, and how much ci-sdk would save. Run it in your repo:

```bash
npx ci-sdk scan
```

- Looks at the last 30 days of workflow runs (`--days`, `--max-runs` to change).
- Estimates savings from your repo's own history: repeated runs, tests a change could not reach (via an oxc import graph), and slow installs.
- `--markdown` for a PR or Slack, `--json` for tooling.
- Needs a GitHub token with **Actions: read**. Uses `GITHUB_TOKEN`, `GH_TOKEN`, or `gh auth token`.
- Runs locally. Your code and CI data never leave your machine.
